#!/bin/sh
# cleanup temp files
find /tmp -name '*.tmp' -delete
